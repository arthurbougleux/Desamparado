#ifndef _level_hpp_INCLUDED
#define _level_hpp_INCLUDED

#include <climits>

namespace CaDiCaL {

// For each new decision we increase the decision level and push a 'Level'
// on the 'control' stack.  The information gathered here is used in
// 'reuse_trail' and for early aborts in clause minimization.

struct Level {

  int decision; // decision literal of this level
  int trail;    // trail start of this level

  int subComeLevel;     // The level only low by the  physicalLevel in the reason clause lits 


  struct {
    int count; // how many variables seen during 'analyze'
    int trail; // smallest trail position seen on this level
  } seen;

  void reset () {
    seen.count = 0;
    seen.trail = INT_MAX;
  }

  //Level (int d, int t) : decision (d), trail (t) { reset (); }
  Level (int d, int t, int l = 0) : decision (d), trail (t) , subComeLevel (l) { reset (); }
  Level () {}
};

} // namespace CaDiCaL

#endif
