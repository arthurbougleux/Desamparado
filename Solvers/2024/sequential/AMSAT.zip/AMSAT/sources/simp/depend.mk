/mnt/e/SatSourceCode/SATCompetition2023/Solver/AMSAT_/AMSAT_/sources/simp/SimpSolver.o /mnt/e/SatSourceCode/SATCompetition2023/Solver/AMSAT_/AMSAT_/sources/simp/SimpSolver.or /mnt/e/SatSourceCode/SATCompetition2023/Solver/AMSAT_/AMSAT_/sources/simp/SimpSolver.od /mnt/e/SatSourceCode/SATCompetition2023/Solver/AMSAT_/AMSAT_/sources/simp/SimpSolver.op: \
 /mnt/e/SatSourceCode/SATCompetition2023/Solver/AMSAT_/AMSAT_/sources/simp/SimpSolver.cc \
 ../mtl/Sort.h ../mtl/Vec.h ../mtl/IntTypes.h ../mtl/XAlloc.h \
 ../simp/SimpSolver.h ../mtl/Queue.h ../core/Solver.h ../mtl/Heap.h \
 ../mtl/Alg.h ../utils/Options.h ../utils/ParseUtils.h \
 ../core/SolverTypes.h ../mtl/Map.h ../mtl/Alloc.h ../utils/ccnr.h \
 ../utils/System.h
/mnt/e/SatSourceCode/SATCompetition2023/Solver/AMSAT_/AMSAT_/sources/simp/Main.o /mnt/e/SatSourceCode/SATCompetition2023/Solver/AMSAT_/AMSAT_/sources/simp/Main.or /mnt/e/SatSourceCode/SATCompetition2023/Solver/AMSAT_/AMSAT_/sources/simp/Main.od /mnt/e/SatSourceCode/SATCompetition2023/Solver/AMSAT_/AMSAT_/sources/simp/Main.op: \
 /mnt/e/SatSourceCode/SATCompetition2023/Solver/AMSAT_/AMSAT_/sources/simp/Main.cc \
 ../utils/System.h ../mtl/IntTypes.h ../utils/ParseUtils.h \
 ../utils/Options.h ../mtl/Vec.h ../mtl/XAlloc.h ../core/Dimacs.h \
 ../core/SolverTypes.h ../mtl/Alg.h ../mtl/Map.h ../mtl/Alloc.h \
 ../simp/SimpSolver.h ../mtl/Queue.h ../core/Solver.h ../mtl/Heap.h \
 ../utils/ccnr.h
/Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/Main.o /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/Main.or /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/Main.od /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/Main.op: \
  /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/Main.cc \
  ../utils/System.h ../mtl/IntTypes.h ../utils/ParseUtils.h \
  ../utils/Options.h ../mtl/Vec.h ../mtl/XAlloc.h ../core/Dimacs.h \
  ../core/SolverTypes.h ../mtl/Alg.h ../mtl/Map.h ../mtl/Alloc.h \
  ../core/Solver.h ../mtl/Heap.h ../utils/ccnr.h
/Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/Solver.o /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/Solver.or /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/Solver.od /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/Solver.op: \
  /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/Solver.cc \
  ../mtl/Sort.h ../mtl/Vec.h ../mtl/IntTypes.h ../mtl/XAlloc.h \
  ../core/Solver.h ../mtl/Heap.h ../mtl/Alg.h ../utils/Options.h \
  ../utils/ParseUtils.h ../core/SolverTypes.h ../mtl/Map.h \
  ../mtl/Alloc.h ../utils/ccnr.h ../utils/System.h
/Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/eliminateVars.o /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/eliminateVars.or /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/eliminateVars.od /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/eliminateVars.op: \
  /Users/cli/GoogleDrive/sat/newSolvers/Maple8+drat/sources/core/eliminateVars.cc \
  ../core/Solver.h ../mtl/Vec.h ../mtl/IntTypes.h ../mtl/XAlloc.h \
  ../mtl/Heap.h ../mtl/Alg.h ../utils/Options.h ../utils/ParseUtils.h \
  ../core/SolverTypes.h ../mtl/Map.h ../mtl/Alloc.h ../utils/ccnr.h \
  ../mtl/Sort.h ../utils/System.h
