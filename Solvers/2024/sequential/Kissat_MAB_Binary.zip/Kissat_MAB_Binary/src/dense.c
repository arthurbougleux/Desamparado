#define INLINE_SORT

#include "allocate.h"
#include "dense.h"
#include "inline.h"
#include "propsearch.h"
#include "proprobe.h"
#include "trail.h"

#include "sort.c"

static void
flush_large_watches(kissat* solver,
	litpairs* irredundant, litwatches* redundant)
{
	assert(!solver->level);
	assert(solver->watching);
#ifndef LOGGING
	LOG("flushing large watches");
	if (irredundant)
		LOG("flushing and saving irredundant binary clauses too");
	else
		LOG("keep watching irredundant binary clauses");
	if (redundant)
		LOG("flushing and saving redundant clauses too");
	else
		LOG("keep watching redundant binary clauses");
#endif
	const value* values = solver->values;
	size_t flushed = 0, collected = 0;
	watches* all_watches = solver->watches;
	for (all_literals(lit))
	{
		const value lit_value = values[lit];
		watches* watches = all_watches + lit;
		watch* begin = BEGIN_WATCHES(*watches), * q = begin;
		const watch* end_watches = END_WATCHES(*watches), * p = q;
		while (p != end_watches)
		{
			const watch watch = *p++;
			if (watch.type.binary)
			{
				const unsigned other = watch.binary.lit;
				const value other_value = values[other];
				if (!lit_value && !other_value)
				{
					if (irredundant && !watch.binary.redundant)
					{
						const unsigned other = watch.binary.lit;
						if (lit < other)
						{
							const litpair litpair = { .lits = {lit, other} };
							PUSH_STACK(*irredundant, litpair);
						}
					}
					else if (redundant && watch.binary.redundant)
					{
						const unsigned other = watch.binary.lit;
						if (lit < other)
						{
							const litwatch litwatch = { lit, watch };
							PUSH_STACK(*redundant, litwatch);
						}
					}
					else
						*q++ = watch;
				}
				else
				{
					assert(lit_value > 0 || other_value > 0);
					if (lit < other)
					{
						const bool red = watch.binary.redundant;
						const bool hyper = watch.binary.hyper;
						kissat_delete_binary(solver, red, hyper, lit, other);
						collected++;
					}
				}
			}
			else
			{
				flushed++;
				p++;
			}

		}
		SET_END_OF_WATCHES(*watches, q);
	}
	LOG("flushed %zu large watches", flushed);
	LOG("collected %zu satisfied binary clauses", collected);
	if (irredundant)
		LOG("saved %zu irredundant binary clauses", SIZE_STACK(*irredundant));
	if (redundant)
		LOG("saved %zu redundant binary clauses", SIZE_STACK(*redundant));
	(void)collected;
	(void)flushed;
}

void
kissat_enter_dense_mode(kissat* solver,
	litpairs* irredundant, litwatches* redundant)
{
	assert(!solver->level);
	assert(solver->watching);
	assert(solver->propagated == SIZE_STACK(solver->trail));
	LOG("entering dense mode with full occurrence lists");
	if (irredundant || redundant)
		flush_large_watches(solver, irredundant, redundant);
	else
		kissat_flush_large_watches(solver);
	LOG("switched to full occurrence lists");
	solver->watching = false;
}

/*static litwatch* add_binary_watches_into_stack(kissat* solver, bwatch_stack* bistack, litwatch* begin, const litwatch* end, unsigned lit)
{
	do
	{
		unsigned first = begin->lit;
		binary_watch bwatch = begin->watch.binary;
		if (first != lit) break;
		begin++;
		
		unsigned block = bwatch.lit;
		if (solver->marks[block] && lit < block)
		{
			const bool hyper = bwatch.hyper;
			kissat_delete_binary(solver, true, hyper, lit, block);
		}
		else
		{
			solver->marks[block] = 1;
			PUSH_STACK(*bistack, bwatch);
		}
	} while (begin < end);

	for (all_stack(binary_watch, bwatch, *bistack))
	{
		unsigned block = bwatch.lit;
		solver->marks[block] = 0;
	}

	return begin;
}*/

void initialize_redundant_binary_watches(kissat* solver, litwatches* binaries, vectors* binary_vectors, watches* binary_watches)
{
	for (all_stack(litwatch, lw, *binaries))
	{
		unsigned lit = lw.lit;
		watch w = lw.watch;
		unsigned other = w.binary.lit;
		watches* lit_w = binary_watches + lit;
		kissat_push_vectors(solver, binary_vectors, lit_w, w.raw);
		watches* other_w = binary_watches + other;
		w.binary.lit = lit;
		kissat_push_vectors(solver, binary_vectors, other_w, w.raw);
	}
}

void remove_duplicated_and_eliminated_binary(kissat* solver, vectors* binary_vectors, watches* binary_watches, unsigned lit, watches* lit_watches)
{
	if (!lit_watches->size)
		return;

	const flags* flags = solver->flags;
	mark* marks = solver->marks;

	watch* lit_begin = (watch*)kissat_begin_vector(binary_vectors, lit_watches);
	watch* lit_end = (watch*)kissat_end_vector(binary_vectors, lit_watches);
	watch* p = lit_begin, * q = lit_begin;

	while (p < lit_end)
	{
		watch w = *p++;
		assert(w.type.binary);
		unsigned block = w.binary.lit;

		unsigned block_idx = IDX(block);
		if (flags[block_idx].eliminated)
		{
			const bool hyper = w.binary.hyper;
			kissat_delete_binary(solver, true, hyper, lit, block);
			watches* block_w = binary_watches + block;
			w.binary.lit = lit;
			kissat_remove_from_vector(solver, binary_vectors, block_w, w.raw);
			continue;
		}

		if (marks[block])
		{
			const bool hyper = w.binary.hyper;
			kissat_delete_binary(solver, true, hyper, lit, block);
			watches* block_w = binary_watches + block;
			w.binary.lit = lit;
			kissat_remove_from_vector(solver, binary_vectors, block_w, w.raw);
			continue;
		}

		marks[block] = 1;
		*q++ = w;
	}
	sector new_size = q - lit_begin;
	kissat_resize_vector(solver, binary_vectors, lit_watches, new_size);
	
	lit_begin = (watch*)kissat_begin_vector(binary_vectors, lit_watches);
	lit_end = (watch*)kissat_end_vector(binary_vectors, lit_watches);
	while (lit_begin < lit_end)
	{
		watch w = *lit_begin++;
		marks[w.binary.lit] = 0;
	}
}

void delete_binary(kissat* solver, vectors* binary_vectors, watches* binary_watches, unsigned del)
{
	watches* del_watches = binary_watches + del;
	watch* del_begin = (watch*)kissat_begin_vector(binary_vectors, del_watches);
	const watch* del_end = (watch*)kissat_end_vector(binary_vectors, del_watches);

	while (del_begin < del_end)
	{
		watch del_watch = *del_begin++;
		unsigned block = del_watch.binary.lit;
		const bool hyper = del_watch.binary.hyper;
		kissat_delete_binary(solver, true, hyper, del, block);

		watches* block_watches = binary_watches + block;
		del_watch.binary.lit = del;
		kissat_remove_from_vector(solver, binary_vectors, block_watches, del_watch.raw);
	}
	kissat_resize_vector(solver, binary_vectors, del_watches, 0);
}

static void
resume_watching_binaries_in_elimination(kissat* solver, litwatches* binaries)
{
	assert(binaries);
#ifdef LOGGING
	size_t resumed_watching = 0;
	size_t flushed_eliminated = 0;
#endif
	const flags* flags = solver->flags;

	vectors binary_vectors;
	INIT_STACK(binary_vectors.stack);
	binary_vectors.usable = 0;
	watches* binary_watches = kissat_calloc(solver, 2 * solver->vars, sizeof(watches));
	memset(binary_watches, 0, 2 * solver->vars * sizeof(watches));
	initialize_redundant_binary_watches(solver, binaries, &binary_vectors, binary_watches);

	for (all_variables(idx))
	{
		if (!flags[idx].eliminated)
			continue;

		unsigned lit = LIT(idx);
		unsigned not_lit = NOT(lit);
		watches* lit_w = binary_watches + lit;
		watches* not_w = binary_watches + not_lit;
		if (!lit_w->size && !not_w->size)
			continue;

		remove_duplicated_and_eliminated_binary(solver, &binary_vectors, binary_watches, lit, lit_w);
		remove_duplicated_and_eliminated_binary(solver, &binary_vectors, binary_watches, not_lit, not_w);

		if (lit_w->size && not_w->size)
		{
			watch* lit_begin = (watch*)kissat_begin_vector(&binary_vectors, lit_w);
			const watch* lit_end = (watch*)kissat_end_vector(&binary_vectors, lit_w);
			while (lit_begin < lit_end)
			{
				watch lit_watch = *lit_begin++;
				bool lit_hyper = lit_watch.binary.hyper;
				unsigned lit_block = lit_watch.binary.lit;

				watch* not_begin = (watch*)kissat_begin_vector(&binary_vectors, not_w);
				const watch* not_end = (watch*)kissat_end_vector(&binary_vectors, not_w);
				while (not_begin < not_end)
				{
					watch not_watch = *not_begin++;
					bool not_hyper = not_watch.binary.hyper;
					unsigned not_block = not_watch.binary.lit;

					INC(clauses_redundant);
					INC(clauses_added);
					CHECK_AND_ADD_BINARY(lit_block, not_block);
					ADD_BINARY_TO_PROOF(lit_block, not_block);

					watches* lit_block_watches = binary_watches + lit_block;
					watches* not_block_watches = binary_watches + not_block;

					watch new_watch;
					new_watch.type.binary = true;
					new_watch.binary.hyper = lit_hyper && not_hyper ? true : false;
					new_watch.binary.redundant = true;
					new_watch.binary.lit = not_block;

					kissat_push_vectors(solver, &binary_vectors, lit_block_watches, new_watch.raw);
					new_watch.binary.lit = lit_block;
					kissat_push_vectors(solver, &binary_vectors, not_block_watches, new_watch.raw);
				}
			}

			delete_binary(solver, &binary_vectors, binary_watches, lit);
			delete_binary(solver, &binary_vectors, binary_watches, not_lit);
		}
		else
		{
			unsigned del = lit_w->size ? lit : not_lit;
			delete_binary(solver, &binary_vectors, binary_watches, del);
		}
	}

	watches* all_watches = solver->watches;
	for (all_literals(lit))
	{
		watches* old_watches = binary_watches + lit;
		if (!old_watches->size)
			continue;
		
		watches* new_watches = all_watches + lit;
		watch* begin = (watch*)kissat_begin_vector(&binary_vectors, old_watches);
		const watch* end = (watch*)kissat_end_vector(&binary_vectors, old_watches);
		while (begin < end)
		{
			watch w = *begin++;
			PUSH_WATCHES(*new_watches, w);
		}

		kissat_release_vector(solver, &binary_vectors, old_watches);
	}

	RELEASE_STACK(binary_vectors.stack);
	kissat_dealloc(solver, binary_watches, 2 * solver->vars, sizeof(watches));
}

static void
resume_watching_binaries_after_elimination(kissat* solver,
	litwatches* binaries)
{
	assert(binaries);
#ifdef LOGGING
	size_t resumed_watching = 0;
	size_t flushed_eliminated = 0;
#endif
	const flags* flags = solver->flags;
	watches* all_watches = solver->watches;
	for (all_stack(litwatch, litwatch, *binaries))
	{
		const unsigned first = litwatch.lit;
		watch watch = litwatch.watch;
		const unsigned second = watch.binary.lit;
		const unsigned first_idx = IDX(first);
		const unsigned second_idx = IDX(second);
		if (!flags[first_idx].eliminated && !flags[second_idx].eliminated)
		{
			watches* first_watches = all_watches + first;
			PUSH_WATCHES(*first_watches, watch);
			watches* second_watches = all_watches + second;
			watch.binary.lit = first;
			PUSH_WATCHES(*second_watches, watch);
#ifdef LOGGING
			resumed_watching++;
#endif
		}
		else
		{
			const bool redundant = watch.binary.redundant;
			const bool hyper = watch.binary.hyper;
			kissat_delete_binary(solver, redundant, hyper, first, second);
#ifdef LOGGING
			flushed_eliminated++;
#endif
		}
	}
	LOG("resumed watching %zu binary clauses flushed %zu eliminated",
		resumed_watching, flushed_eliminated);
}

static void
completely_resume_watching_binaries (kissat * solver, litwatches * binaries)
{
  assert (binaries);
#ifdef LOGGING
  size_t resumed_watching = 0;
#endif
  watches *all_watches = solver->watches;
  for (all_stack (litwatch, litwatch, *binaries))
    {
      const unsigned first = litwatch.lit;
      watch watch = litwatch.watch;
      const unsigned second = watch.binary.lit;
      assert (!ELIMINATED (IDX (first)));
      assert (!ELIMINATED (IDX (second)));
      watches *first_watches = all_watches + first;
      PUSH_WATCHES (*first_watches, watch);
      watches *second_watches = all_watches + second;
      watch.binary.lit = first;
      PUSH_WATCHES (*second_watches, watch);
#ifdef LOGGING
      resumed_watching++;
#endif
    }
  LOG ("resumed watching %zu binary clauses", resumed_watching);
}

static void
resume_watching_irredundant_binaries (kissat * solver, litpairs * binaries)
{
  assert (binaries);
#ifdef LOGGING
  size_t resumed_watching = 0;
#endif
  watches *all_watches = solver->watches;
  for (all_stack (litpair, litpair, *binaries))
    {
      const unsigned first = litpair.lits[0];
      const unsigned second = litpair.lits[1];

      assert (!ELIMINATED (IDX (first)));
      assert (!ELIMINATED (IDX (second)));

      watches *first_watches = all_watches + first;
      watch first_watch = kissat_binary_watch (second, false, false);
      PUSH_WATCHES (*first_watches, first_watch);

      watches *second_watches = all_watches + second;
      watch second_watch = kissat_binary_watch (first, false, false);
      PUSH_WATCHES (*second_watches, second_watch);

#ifdef LOGGING
      resumed_watching++;
#endif
    }
  LOG ("resumed watching %zu binary clauses", resumed_watching);
}

static void resume_watching_large_clauses_after_elimination (kissat * solver)
{
#ifdef LOGGING
  size_t resumed_watching_redundant = 0;
  size_t resumed_watching_irredundant = 0;
#endif
  const flags *flags = solver->flags;
  watches *watches = solver->watches;
  const value *values = solver->values;
  const assigned *assigned = solver->assigned;
  const word *arena = BEGIN_STACK (solver->arena);

  for (all_clauses (c))
    {
      if (c->garbage)
	continue;
      bool collect = false;
      for (all_literals_in_clause (lit, c))
	{
	  if (values[lit] > 0)
	    {
	      LOGCLS (c, "%s satisfied", LOGLIT (lit));
	      collect = true;
	      break;
	    }
	  const unsigned idx = IDX (lit);
	  if (flags[idx].eliminated)
	    {
	      LOGCLS (c, "containing eliminated %s", LOGLIT (lit));
	      collect = true;
	      break;
	    }
	}
      if (collect)
	{
	  kissat_mark_clause_as_garbage (solver, c);
	  continue;
	}

      assert (c->size > 2);

      unsigned *lits = c->lits;
      kissat_sort_literals (solver, values, assigned, c->size, lits);
      c->searched = 2;

      const reference ref = (word *) c - arena;
      const unsigned l0 = lits[0];
      const unsigned l1 = lits[1];

      kissat_push_blocking_watch (solver, watches + l0, l1, ref);
      kissat_push_blocking_watch (solver, watches + l1, l0, ref);

#ifdef LOGGING
      if (c->redundant)
	resumed_watching_redundant++;
      else
	resumed_watching_irredundant++;
#endif
    }
  LOG ("resumed watching %zu irredundant and %zu redundant large clauses",
       resumed_watching_irredundant, resumed_watching_redundant);
}

void kissat_resume_sparse_mode(kissat* solver, bool flush_eliminated, bool from_eliminate, litpairs* irredundant, litwatches* redundant)
{
	assert(!solver->level);
	assert(!solver->watching);
	if (solver->inconsistent)
		return;
	LOG("resuming sparse mode watching clauses");
	kissat_flush_large_connected(solver);
	LOG("switched to watching clauses");
	solver->watching = true;
	if (irredundant)
	{
		LOG("resuming watching %zu irredundant binaries",
			SIZE_STACK(*irredundant));
		resume_watching_irredundant_binaries(solver, irredundant);
	}
	if (redundant)
	{
		LOG("resuming watching %zu redundant binaries",
			SIZE_STACK(*redundant));
		if (from_eliminate)
			resume_watching_binaries_in_elimination(solver, redundant);
		else if (flush_eliminated)
			resume_watching_binaries_after_elimination(solver, redundant);
		else
			completely_resume_watching_binaries(solver, redundant);
	}

	if (flush_eliminated)
		resume_watching_large_clauses_after_elimination(solver);
	else
		kissat_watch_large_clauses(solver);
	LOG("forcing to propagate units on all clauses");
	solver->propagated = 0;

	clause* conflict;
	if (solver->probing)
		conflict = kissat_probing_propagate(solver, 0);
	else
		conflict = kissat_search_propagate(solver);
	if (conflict)
	{
		LOG("conflict during propagation after resuming sparse mode");
		solver->inconsistent = true;
		CHECK_AND_ADD_EMPTY();
		ADD_EMPTY_TO_PROOF();
	}
	else if (solver->unflushed)
		kissat_flush_trail(solver);
}
